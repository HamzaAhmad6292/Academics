#include <iostream>
#include "mygraphics.h"
#include "myconsole.h"
using namespace std;

int main()
{
    int win_x, win_y;
    int box_x, box_y, box_x1, box_y1, box_x2, box_y2, box_x3, box_y3;
    int ball_x, ball_y;
    bool dir = false;
    bool flag = true;
    char demo[] = "demo";
    char space[] = "space";
    bool pressed = false;
    int lives = 3;

    //system("pause");

    GetMaxWindowCoordinates(win_x, win_y);

    box_x = 800;
    box_y = 0;
    box_x1 = 200;
    box_y1 = 0;
    box_x2 = 200;
    box_y2 = 0;
    box_x3 = 600;
    box_y3 = 0;
    ball_x = win_x / 2;
    ball_y = win_y +780;

 

    PlaceCursor(0, 0);
    while (flag) {			//GAME LOOP




        // random box spawn
          // to be continued

        // random box spawn





        //BOX MOVEMENT

        box_y += 5 - dir * 50;
        if (box_y + 50 >= win_y + 780)
        {
            box_y = 0;
            box_x = 800;
        }
        myRect(box_x, box_y, box_x + 50, box_y + 50, RGB(0, 255, 0), RGB(0, 255, 0));

        box_y1 += 5 - dir * 50;
        if (box_y1 + 50 >= win_y + 780)
        {
            box_y1 = 0;
            box_x1 = 200;
        }
        myRect(box_x1, box_y1, box_x1 + 50, box_y1 + 50, RGB(0, 255, 0), RGB(0, 255, 0));



        box_y2 += 5 - dir * 50;
        if (box_y2 + 50 >= win_y + 780)
        {
            box_y2 = 0;
            box_x2 = 400;
        }
        myRect(box_x2, box_y2, box_x2 + 50, box_y2 + 50, RGB(0, 255, 0), RGB(0, 255, 0));

        box_y3 += 5 - dir * 50;
        if (box_y3 + 50 >= win_y + 780)
        {
            box_y3 = 0;
            box_x3 = 600;
        }
        myRect(box_x3, box_y3, box_x3 + 50, box_y3 + 50, RGB(0, 255, 0), RGB(0, 255, 0));


        //MOVE BALL WITH LEFT AND RIGHT ARROW KEYS. PRESS SPACE TO CHANGE TEXT
        int a = CheckKeyPressed();
    int  b= CheckKeyPressed1();

        if (a == LEFTKEY)
        {
            if (ball_x >=40)
            {

                myEllipse(ball_x, ball_y, ball_x + 50, ball_y + 50, RGB(0, 0, 0), RGB(0, 0, 0));
                ball_x -= 45;
            }
        }
        else if (a == RIGHTKEY)
        {
            if (ball_x < 1800)
            {
                myEllipse(ball_x, ball_y, ball_x + 50, ball_y + 50, RGB(0, 0, 0), RGB(0, 0, 0));
                ball_x += 40;
            }
        }
        else if (a==UPKEY)
        {
            myEllipse(ball_x, ball_y, ball_x + 50, ball_y + 50, RGB(0, 0, 0), RGB(0, 0, 0));
        ball_y - 50;
        }
        else if (a==DOWNKEY)
        {
            myEllipse(ball_x, ball_y, ball_x + 50, ball_y + 50, RGB(0, 0, 0), RGB(0, 0, 0));
           ball_y + 50;
        }
           

        // Sleep(10);

        
       // frame
       

        
        
           // Game board 
        myRect(0, 0, 2000, 1000, RGB(5, 5, 5), RGB(5, 5, 5));
        // Game board

          // The Box

        myRect(1700, 0, 1705, 150, RGB(255, 0, 255), RGB(255 , 0, 255));
        myRect(1700, 150, 1870, 155, RGB(255, 0, 255), RGB(255, 0, 255));
       
          
      // The Box 
        //left line
        myLine(0, 0 , 0, 2000, RGB(0, 0, 0));
        myRect(0, 0, 20,1000 , RGB(0, 0, 255), RGB(0, 0, 255));     
        //left line

         //uper line
        myLine(0, 0, 2000, 0, RGB(0, 0, 0));
        myRect(0, 0, 2000, 20, RGB(0, 0, 255), RGB(0, 0, 255));
        //uper line

        //right line
        myLine(1890, 0, 1890, 0, RGB(0, 0, 0));
        myRect(1870, 0, 2000, 1000, RGB(0, 0, 255), RGB(0, 0, 255));
        //right line

          //bottom line
        myLine(0, 985, 2000, 985, RGB(0, 0, 0));
        myRect(0, 965, 2000, 985, RGB(0, 0, 255), RGB(0, 0, 255));
        //bottom line

        // frame 

        myRect(box_x, box_y, box_x + 50, box_y + 50, RGB(0, 0, 0), RGB(0, 0, 0));
        myRect(box_x1, box_y1, box_x1 + 50, box_y1 + 50, RGB(0, 0, 0), RGB(0, 0, 0));
        myRect(box_x2, box_y2, box_x2 + 50, box_y2 + 50, RGB(0, 0, 0), RGB(0, 0, 0));
        myRect(box_x3, box_y3, box_x3 + 50, box_y3 + 50, RGB(0, 0, 0), RGB(0, 0, 0));

       
        myEllipse(ball_x, ball_y, ball_x + 50, ball_y + 50, RGB(0, 0, 255), RGB(0, 255, 255));
    }

}
