#include <iostream>
#include "mygraphics.h"
#include "myconsole.h"
#include  <cstring>
#include <cstdlib>
using namespace std;

int main()

{
    int win_x, win_y;
    int box_x, box_y, box_x1, box_y1, box_x2, box_y2, box_x3, box_y3;
    int ball_x, ball_y;
    bool dir = false;
    bool flag = true;
    char demo[] = "demo";
    char lives3[] = "3";
    char lives2[] = "2";
    char lives1[] = "1";
    char lives0[] = "0";
    bool pressed = false;
    bool lives = true;
    int count = 0;





   
    //system("pause");

    GetMaxWindowCoordinates(win_x, win_y);

    box_x = 800;
    box_y = 0;
    box_x1 = 200;
    box_y1 = 0;
    box_x2 = 200;
    box_y2 = 0;
    box_x3 = 600;
    box_y3 = 0;
    
    int r = 0;
    int s =0;
    int t = 0;
    int u = 0;

    ball_x = win_x / 2;
    ball_y = win_y +780;

 

    PlaceCursor(0, 0);
    while (flag) {			//GAME LOOP




        // random box speed
      
        // random box speed

        //Aliens

        box_y += 2 - dir * 50;
        if (box_y + 50 >= win_y + 780)
        {
            box_y = 0;
            r = (rand() % 1500 + rand()%50);
            count++;
        }
        myEllipse(r, box_y, r + 75, box_y + 50, RGB(0, 255, 0), RGB(0, 255, 0));
        myEllipse(r + 15, box_y, r + 30, box_y + 20, RGB(255, 0, 0), RGB(255, 0, 0));
        myEllipse(r+50, box_y, r + 65, box_y + 20, RGB(255, 0, 0), RGB(255, 0, 0));

        box_y1 += 2 - dir * 50;
        if (box_y1 + 50 >= win_y + 780)
        {
            box_y1 = 0;
             s=(rand() % 1500 +rand()%100);
            count++;
            
        }
        myEllipse(s, box_y1, s + 75, box_y1 + 50, RGB(0, 255, 0), RGB(0, 255, 0));
        myEllipse(s + 15, box_y1, s + 30, box_y1 + 20, RGB(255, 0, 0), RGB(255, 0, 0));
        myEllipse(s + 50, box_y1, s + 65, box_y1 + 20, RGB(255, 0, 0), RGB(255, 0, 0));



        box_y2 += 2 - dir * 50;
        if (box_y2 + 50 >= win_y + 780)
        {
            box_y2 = 0;
            t = (rand() % 1500  + rand()%150);
            count++;
        }
        myEllipse(t, box_y2, t + 75, box_y2 + 50, RGB(0, 255, 0), RGB(0, 255, 0));
        myEllipse(t + 15, box_y2, t + 30, box_y2 + 20, RGB(255, 0, 0), RGB(255, 0, 0));
        myEllipse(t + 50, box_y2, t + 65, box_y2 + 20, RGB(255, 0, 0), RGB(255, 0, 0));


        box_y3 += 2 - dir * 50;
        if (box_y3 + 50 >= win_y + 780)
        {
            box_y3 = 0;
            u = (rand() % 1500 + rand()%200);
            count++;
        }
        myEllipse(u, box_y2, u + 75, box_y3 + 50, RGB(0, 255, 0), RGB(0, 255, 0));
        myEllipse(u + 15, box_y3, u + 30, box_y3 + 20, RGB(255, 0, 0), RGB(255, 0, 0));
        myEllipse(u + 50, box_y3, u + 65, box_y3 + 20, RGB(255, 0, 0), RGB(255, 0, 0));


        //lives

        if (count == 0)
        {
            myDrawTextWithFont(1750, 75, 30, lives3, RGB(0, 255, 0), RGB(20, 20, 20));
           
        }
        if (count == 1)
        {
            myDrawTextWithFont(1750, 75, 30, lives3, RGB(0, 0, 0), RGB(0, 0, 0));
            myDrawTextWithFont(1750, 75, 30, lives2, RGB(0, 255, 0), RGB(20, 20, 20));
        }
        else if (count == 2)
        {
            myDrawTextWithFont(1750, 75, 30, lives2, RGB(0, 0, 0), RGB(0, 0, 0));

            myDrawTextWithFont(1750, 75, 30, lives1, RGB(0, 255, 0), RGB(20, 20, 20));
        }

        else if (count == 10000000)
        {
            myDrawTextWithFont(1750, 75, 30, lives1, RGB(0, 0, 0), RGB(0, 0, 0));
            myDrawTextWithFont(1750, 75, 30, lives0, RGB(0, 255, 0), RGB(20, 20, 20));
            break;
        }
        //lives







        //MOVE BALL WITH LEFT AND RIGHT ARROW KEYS. PRESS SPACE TO CHANGE TEXT
        int a = CheckKeyPressed();
    int  b= CheckKeyPressed1();

        if (a == LEFTKEY)
        {
            if (ball_x >=40)
            {
                myLine(ball_x + 40, ball_y - 10, ball_x + 40, ball_y - 40, RGB(12, 12, 12));
                myLine(ball_x + 110, ball_y - 10, ball_x + 110, ball_y - 40, RGB(12, 12, 12));

                myLine(ball_x + 60, ball_y - 10, ball_x + 60, ball_y - 25, RGB(12, 12, 12));
                myLine(ball_x + 90, ball_y - 10, ball_x + 90, ball_y - 25, RGB(12, 12, 12));






                myRect(ball_x + 72, ball_y - 20, ball_x + 77, ball_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));


                myEllipse(ball_x + 150, ball_y - 30, ball_x + 160, ball_y + 40, RGB(12, 12, 12), RGB(12, 12, 12));
                myEllipse(ball_x - 10, ball_y - 30, ball_x, ball_y + 40, RGB(12, 12, 12), RGB(12, 12, 12));


                myEllipse(ball_x + 20, ball_y - 10, ball_x + 130, ball_y, RGB(12, 12, 12), RGB(12, 12, 12));
                myEllipse(ball_x, ball_y, ball_x + 150, ball_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));
                ball_x -= 45;
            }
        }
        else if (a == RIGHTKEY)
        {
            if (ball_x < 1800)
            {
                myLine(ball_x + 40, ball_y - 10, ball_x + 40, ball_y - 40, RGB(12, 12, 12));
                myLine(ball_x + 110, ball_y - 10, ball_x + 110, ball_y - 40, RGB(12, 12, 12));

                myLine(ball_x + 60, ball_y - 10, ball_x + 60, ball_y - 25, RGB(12, 12, 12));
                myLine(ball_x + 90, ball_y - 10, ball_x + 90, ball_y - 25, RGB(12, 12, 12));






                myRect(ball_x + 72, ball_y - 20, ball_x + 77, ball_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));


                myEllipse(ball_x + 150, ball_y - 30, ball_x + 160, ball_y + 40, RGB(12, 12, 12), RGB(12, 12, 12));
                myEllipse(ball_x - 10, ball_y - 30, ball_x, ball_y + 40, RGB(12, 12, 12), RGB (12, 12, 12));


                myEllipse(ball_x + 20, ball_y - 10, ball_x + 130, ball_y, RGB(12, 12, 12), RGB(12, 12, 12));
                myEllipse(ball_x, ball_y, ball_x + 150, ball_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));
                ball_x += 40;
            }
        }
        else if (a==UPKEY)
        {
            myLine(ball_x + 40, ball_y - 10, ball_x + 40, ball_y - 40, RGB(12, 12, 12));
            myLine(ball_x + 110, ball_y - 10, ball_x + 110, ball_y - 40, RGB(12, 12, 12));

            myLine(ball_x + 60, ball_y - 10, ball_x + 60, ball_y - 25, RGB(12, 12, 12));
            myLine(ball_x + 90, ball_y - 10, ball_x + 90, ball_y - 25, RGB(12, 12, 12));






            myRect(ball_x + 72, ball_y - 20, ball_x + 77, ball_y + 20, RGB(150, 0, 0), RGB(0, 0, 0));


            myEllipse(ball_x + 150, ball_y - 30, ball_x + 160, ball_y + 40, RGB(0, 0, 0), RGB(0, 0, 0));
            myEllipse(ball_x - 10, ball_y - 30, ball_x, ball_y + 40, RGB(0, 0, 0), RGB(0, 0, 0));

            myRect(ball_x+31, ball_y - 20, ball_x + 63, ball_y + 40, RGB(0, 0, 0), RGB(0, 0, 0));
            myRect(ball_x, ball_y, ball_x + 150, ball_y + 20, RGB(0, 0, 0), RGB(0, 0, 0));
        ball_y - 50;
        }
        else if (a==DOWNKEY)
        {
            myLine(ball_x + 40, ball_y - 10, ball_x + 40, ball_y - 40, RGB(0, 0, 0));
            myLine(ball_x + 110, ball_y - 10, ball_x + 110, ball_y - 40, RGB(0, 0, 0));

            myLine(ball_x + 60, ball_y - 10, ball_x + 60, ball_y - 25, RGB(0, 0, 0));
            myLine(ball_x + 90, ball_y - 10, ball_x + 90, ball_y - 25, RGB(0, 0, 0));






            myRect(ball_x + 72, ball_y - 20, ball_x + 77, ball_y + 20, RGB(150, 0, 0), RGB(150, 0, 0));


            myEllipse(ball_x + 150, ball_y - 30, ball_x + 160, ball_y + 40, RGB(220, 220, 220), RGB(220, 220, 220));
            myEllipse(ball_x - 10, ball_y - 30, ball_x, ball_y + 40, RGB(220, 220, 220), RGB(220, 220, 220));

            myRect(ball_x +31, ball_y - 20, ball_x + 63, ball_y + 40, RGB(0, 0, 0), RGB(0, 0, 0));
            myRect(ball_x, ball_y, ball_x + 150, ball_y + 20, RGB(0, 0, 0), RGB(0, 0, 0));
            ball_y + 50;
        }
           
      
        // Sleep(10);

        
       // frame
       

        
        
           // Game board 
       // myRect(0, 0, 2000, 1000, RGB(5, 5, 5), RGB(5, 5, 5));
        // Game board

          // The Box
        myRect(1700, 0, 1705, 150, RGB(255, 0, 255), RGB(255 , 0, 255));
        myRect(1700, 150, 1870, 155, RGB(255, 0, 255), RGB(255, 0, 255));
          // The Box 
        
      
        //left line
        myLine(0, 0 , 0, 2000, RGB(0, 0, 0));
        myRect(0, 0, 20,1000 , RGB(0, 0, 255), RGB(0, 0, 255));     
        //left line

         //uper line
        myLine(0, 0, 2000, 0, RGB(0, 0, 0));
        myRect(0, 0, 2000, 20, RGB(0, 0, 255), RGB(0, 0, 255));
        //uper line

        //right line
        myLine(1890, 0, 1890, 0, RGB(0, 0, 0));
        myRect(1870, 0, 2000, 1000, RGB(0, 0, 255), RGB(0, 0, 255));
        //right line

          //bottom line
        myLine(0, 985, 2000, 985, RGB(0, 0, 0));
        myRect(0, 965, 2000, 985, RGB(0, 0, 255), RGB(0, 0, 255));
        //bottom line
        // frame 






       //Aliens
        myEllipse(r, box_y, r + 75, box_y + 50, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(r + 15, box_y, r + 30, box_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(r + 50, box_y, r + 65, box_y + 20, RGB(12, 12, 12), RGB(12, 12, 12));


        myEllipse(s, box_y1, s + 75, box_y1 + 50, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(s + 15, box_y1, s + 30, box_y1 + 20, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(s + 50, box_y1, s + 65, box_y1 + 20, RGB(12, 12, 12), RGB(12, 12, 12));


        myEllipse(t, box_y2, t + 75, box_y2 + 50, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(t + 15, box_y2, t + 30, box_y2 + 20, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(t + 50, box_y2, t + 65, box_y2 + 20, RGB(12, 12, 12), RGB(12, 12, 12));


        myEllipse(u, box_y3, u + 75, box_y3 + 50, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(u + 15, box_y3, u + 30, box_y3 + 20, RGB(12, 12, 12), RGB(12, 12, 12));
        myEllipse(u + 50, box_y3, u + 65, box_y3 + 20, RGB(12, 12, 12), RGB(12, 12, 12));
       //Aliens
        
       
       //spaceship
        myLine(ball_x+40, ball_y - 10, ball_x+40, ball_y-40, RGB(255, 255, 51));
        myLine(ball_x + 110, ball_y - 10, ball_x + 110, ball_y - 40, RGB(255, 255, 51));

        myLine(ball_x + 60, ball_y - 10, ball_x + 60, ball_y - 25, RGB(255, 0, 0));
        myLine(ball_x + 90, ball_y - 10, ball_x + 90, ball_y - 25, RGB(255, 0, 0));






        myRect(ball_x + 72, ball_y - 20, ball_x + 77, ball_y+20, RGB(150, 0, 0), RGB(150, 0, 0));


        myEllipse(ball_x +150, ball_y - 30, ball_x+160, ball_y + 40, RGB(220, 220, 220), RGB(220, 220, 220));
        myEllipse(ball_x -10, ball_y - 30, ball_x , ball_y + 40, RGB(220, 220, 220), RGB(220, 220, 220));
        
        
        myEllipse(ball_x+20, ball_y - 10, ball_x + 130, ball_y , RGB(72, 23, 23), RGB(72, 23, 23));
        myEllipse(ball_x, ball_y, ball_x + 150, ball_y + 20, RGB(100, 100, 100), RGB(100, 100, 100));
        //spaceship









    }
    return 0;


}
