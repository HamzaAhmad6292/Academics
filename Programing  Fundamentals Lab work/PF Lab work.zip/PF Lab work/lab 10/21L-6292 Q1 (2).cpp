#include<iostream>
#include<string>
using namespace std;
int main()
{
	int l;
	int x;
	string s;
	cin>>s;
	l=s.length();
	for(x=l-1;x>=0;x--)
	{
		cout<<s[x];

	}
	cout<<endl;
	system("pause");
	return 0;





}