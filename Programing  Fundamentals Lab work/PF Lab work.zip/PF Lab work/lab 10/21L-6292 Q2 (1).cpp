#include<iostream>
#include<string>
using namespace std;
int main()
{
	int x;
	int ans;
	int sum=0;
	int l;
	string s;
	getline(cin,s);
	l=s.length();
	for(x=0;x<l;x++)
	{
		if ((s[x]>10) && (s[x]<57))
		{
			ans=int (s[x]-48);
			sum=sum+ans;
		}
	}
	cout<<"Answer:"<<sum<<endl;
	system("pause");
		return 0;




}