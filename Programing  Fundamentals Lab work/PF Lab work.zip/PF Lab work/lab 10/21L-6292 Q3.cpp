#include<iostream>
#include<string>
using namespace std;
int main()
{
	string s;
	int x;
	int y;
	int z;

	int l;
	getline(cin, s);
	l = s.length();
	for (x = 0; x < l; x++)
	{
		y = int(s[x]) - 48;
		z = int(s[x + 1]) - 48;
		if ((y % 2 == 0) && (z % 2 == 0))
		{

			s.insert(x+1, "%");
		}
	}
		
	cout << s << endl;
	system("pause");
	return 0;

	
}