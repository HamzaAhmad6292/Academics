#include<iostream>
using namespace std;
int main()
{
	int i;
	int j;
	int arr[3][3];
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)

		{
			cin >> arr[i][j];
		}
	}
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)

		{
			cout<< arr[j][i];
		}
		cout << endl;
	}
	system("pause");
	return 0;

}