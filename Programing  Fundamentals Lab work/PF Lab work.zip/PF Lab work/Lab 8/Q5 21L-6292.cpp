#include <iostream>
using namespace std;

int main()
{
    int x;
    int y;
    int a[7] = { 5,4,6,-11,-9,18,-7};
    cout << "{";
    for (x = 0; x < 7; x++)
    {
        if (a[x] > 0) 
        {
            cout << a[x];
            cout<< ",";
        }
    }
    for (y = 0; y < 7; y++) {
        if (a[y] < 0) {
            cout << a[y];
            cout<<",";
        }
    }
    cout << "}";

    return 0;
}