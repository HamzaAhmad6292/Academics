#include<iostream>
using namespace std;

int maxi(int a[])
{
	int x;
	int max=0;
	for(x=0;x<=5;x++)
		if(a[x]>max)
		{max=a[x];}
		return max;
}
int mini(int a[])
{
	int x;
	int minin=9999999;
	for(x=0;x<=5;x++)
		if(a[x]<minin)
		{minin=a[x];}
		return minin;
}

int main()
{
	int arr[4];
		int x;
	int y;
	int ma;
	int mi;
	for(x=0;x<=4;x++)
	{
	
		
		cout<<"Enter number "<<x<<":"<<endl;
		cin>>y;
		ma=maxi(arr);
		mi=mini(arr);
		
	}
	cout<<"The Largest Number is:"<<ma<<endl;
		cout<<"The smallest Numnber is :"<<mi;

	return 0;
	system("pause");

}

