#include <iostream>
using namespace std;

int main()
{
    int a[10] = { 2,5,6,8,7,5,3,4,2,1 };
    int sub_arr[3] = { 4,2,1 };

    int size = 3;
    int num, count = 0;
    int f;
    int start = 0;
    for (int x = 0; x < 10; x++) {
        if (a[x] == sub_arr[0]) {
            f = x;

            for (int y = 0; y < size; y++) {
                if (sub_arr[y] == a[f + y]) {
                    count += 1;
                }
                if (count == 2) {
                    cout << "Sub Array exists from " << x + 1 << " to " << x + size;
                }
            }
        }
    }
    return 0;
}
