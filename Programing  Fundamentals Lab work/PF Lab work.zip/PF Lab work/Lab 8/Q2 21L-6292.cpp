#include<iostream>
using namespace std;
int main()
{
	
	int a[5];
	int b;
	int z;
	for(z=0;z<=4;z++)
	{
	
		
		cout<<"Enter number "<<z<<":";
		cin>>a[z];
		cout<<endl;
	
	
	}
	int x;
	int y;
	cout<<"Enter Number to Check";
	cin>>x;
	cin>>y;
	int sum=x+y;
	for(b=0;b<=4;b++)
	{
		if(sum==a[b])
		{ 
			cout<<"Sum exists in the array at index ."<<b;
			break;
	    }

    }
	system("pause");
	return 0;

}
