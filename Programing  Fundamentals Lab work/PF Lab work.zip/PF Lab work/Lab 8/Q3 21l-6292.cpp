#include<iostream>
using namespace std;
int main()
{
	int a[11]={1,1,2,2,3,4,5,6,6,6,7};
	int x;
	int y;
	cout<<"Enter number:"<<y;
	cin>>y;
	int z=0;
	for(x=1;x<=11;x++)
	{
		if(y==a[x])
		{
			z++;
		}
	}

	     cout<<y<<" Occurs "<<z<<" times";
	system("pause");
		return 0;


}