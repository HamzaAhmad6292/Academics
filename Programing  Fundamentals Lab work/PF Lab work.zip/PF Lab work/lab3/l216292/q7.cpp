#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "Input Number:";
	cin >> n;
	int x = 1;
	int gap  =2;
	int y;
	int seq = 2;

	while (x <= n)
	{
		cout << seq << "  ";
		gap = gap + 2;
		seq = seq + gap;
		
		x = x + 1;

	}
	
	return 0;
	system("pause");

}