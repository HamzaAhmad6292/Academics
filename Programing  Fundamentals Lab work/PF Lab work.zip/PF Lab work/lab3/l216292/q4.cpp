
#include<iostream>
using namespace std;
int main()
    {
	int x;
	int y=0;
	int z=1;
	int a;
	int sum=0;
	int avg;
	cout<<"Enter Lenght:";
	cin>>x;
	while(z<=x){
		cout<<"enter number:"<<z<<endl;
		cin>>a;
		sum=sum+a;
		z=z+1;
		avg=sum/x;
	
		
	}
	cout<<"sum"<<"="<<sum<<endl;
	cout<<"avg"<<"="<<avg;

		
	return 0;
	system("pause");
}