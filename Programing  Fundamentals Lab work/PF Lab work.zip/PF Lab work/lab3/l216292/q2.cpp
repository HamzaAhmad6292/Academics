#include<iostream>
using namespace std;
int main()
{
	int x;
	cout<<"enter positive number:";
	cin>>x;
	int y=0;
	int m;
		while(y<=10)
		{
			y=y+1;
			m=x*y;
			cout<<x<<"*"<<y<<"="<<m<<endl;
		}
		return 0;
		system("pause");
}
