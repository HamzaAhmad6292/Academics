#include<iostream>
using namespace std;
int main()
{
	int x;
	int y;
	int z;
	int num;
	int p = 1;
	int sum;
	cout << "Enter any number:";
	cin >> num;
	int ans;
	while (p<2)
	{
		x = (num / 100);
		y = ((num - 100 * x) / 10);
		z = (num - ((100 * x) + (10 * y)));
		sum = x + y + z;
		p = 2;


	}
cout << x << "+" << y << "+" << z << "=" <<sum;
return 0;
system("pause");

}