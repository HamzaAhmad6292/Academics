#include<iostream>
using namespace std;
int main()
{
	int x;
	int power;
	cout<<"Enter a positive number";
	cin>>x;
	cout<<"Enter Power";
	cin>>power;
	int y=1;
	int answer=1;
	
		while(y<=power){
	
	answer=answer*x;
	y=y+1;
		}
	
	cout<<answer;

	return 0;
	system("pause");
}