#include<iostream>
using namespace std;
int main(){

	int x;
cout<<"Enter a positive number:";
cin>>x;
int y=0;
	while(y<=x)
	{
		cout<<y<<"  "  ;
		y=y+1;
	}
	return 0;
	system("pause");
}

