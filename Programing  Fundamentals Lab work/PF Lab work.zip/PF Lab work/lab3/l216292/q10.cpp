#include<iostream>
using namespace std;
int main()
{
	int x = 0;
	int y = 1;
	int z = 0;
	int num;
	int ex = 2;
	cout << "Enter any number: ";
	cin >> num;
	z = x + y;
	cout << x << " " << y << " ";
	while ((num > 3) && (ex < num))
	{
		cout << z << " ";
		x = y;
		y = z;
		z = x + y;

		ex = ex + 1;



	}
	return 0;
	system("pause");
}