#include <iostream>
using namespace std;
int main()
{
	int x = 0;
	int gap = 3;
	int num;
	int number = 3;
	int ans = 6;
	cout << "Enter any number:";
	cin >> num;
	while (x <= num) {
		cout << ans << "  ";
		x = x + 1;
		ans = ans+ gap;
		gap = gap + 2;
	}
	return 0;

	system("pause");

}