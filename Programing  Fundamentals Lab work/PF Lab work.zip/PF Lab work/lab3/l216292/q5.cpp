#include<iostream>
using namespace std;
int main()
{
	int  n;
	cout << "Enter a positive number :";
	cin >> n;
	int x = 1;
	int mul = 1;
	while ((x > 0)&&(x<=n)){ 
	
		mul = mul * x;
		x = x + 1;
		
	}
	cout << "Factorial="<<mul;
return 0;
system("pause");


}