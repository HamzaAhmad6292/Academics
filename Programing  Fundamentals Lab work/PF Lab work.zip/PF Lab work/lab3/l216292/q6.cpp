#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "input a number:";
	cin >> n;
	int x = 0;
	float fac;
	 float sum = 1.0;
	float answer = 0.0;
	while (sum<=n) {
		fac = 1/( sum);
		sum = sum+ 1;
		answer = answer + fac;


			
	}
	cout << "Answer:" << answer;
	return 0;
	system("pause");


}