#include<iostream>
using namespace std;
int main()
{
	int num;
	int x;
	int y;
	char ch;
	cout << "Enter Any Number:";
	cin >> num;
	cout << "�nter the character for pattern:";
	cin >> ch;

	for (x = 0; x < num; x++)
	{
		for (y = 0; y < x; y++)
		{
			cout << ch;
		}
		cout << endl;
	}
	for (x = num; x >= 1; x = x - 1)
	{
		for (y = 0; y < x; y++)
		{
			cout << ch;
		}
		cout << endl;
	}
	return 0;
	system("pause");
}