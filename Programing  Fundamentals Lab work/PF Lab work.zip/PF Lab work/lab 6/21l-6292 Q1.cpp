#include<iostream>
using namespace std;
int main()
{
	int x;
	cout<<"Enter Any Number:";
	cin>>x;
	int a;
	int y;
	int m;
	for(a=0;a<x;a++){
		for(y=0;y<x;y++){
			if(a==y){
				cout<<"0";
			}
			else {
				m=y-a;
				if (m>0){
				    cout<<m;
				}
				if(m<0){
				    m=m*-1;
				    cout<<m;
				}
				
			}
		
		}
		cout<<endl;
	

}
	return 0;
	system("pause");
}