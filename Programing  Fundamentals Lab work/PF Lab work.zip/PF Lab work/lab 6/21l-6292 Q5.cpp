{

int a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0,i=0,j=0,k=0;
int x;
int y;
int num;
cout<<"Enter any number:";
cin>>num;
for(y=0;y<=10;y++)
{
    x=num%10;
    num=num/10;
    

switch(x)
{

case(1):
a=a+1;
break;

case(2):
b=b+1;
break;

case(3):
c=c+1;
break;

case(4):
d=d+1;
break;

case(5):
e=e+1;
break;

case(6):
f=f+1;
break;

case(7):
g=g+1;
break;

case(8):
h=h+1;
break;

case(9):
i=i+1;
break;

case(0):
j=j+1;
break;
}
}
cout<<"The frequency of 1:"<<a<<endl;
cout<<"The frequency of 2:"<<b<<endl;
cout<<"The frequency of 3:"<<c<<endl;
cout<<"The frequency of 4:"<<d<<endl;
cout<<"The frequency of 5:"<<e<<endl;
cout<<"The frequency of 6:"<<f<<endl;
cout<<"The frequency of 7:"<<g<<endl;
cout<<"The frequency of 8:"<<h<<endl;
cout<<"The frequency of 9:"<<i<<endl;
cout<<"The frequency of 0:"<<j<<endl;
return 0;
system("pause");
}

