#include<iostream>
using namespace std;
int main()
{
	int x;
	int a;
	int b;
	cout << "1) Muliply" << endl << "2) Divide" << endl << "3) Addition" << endl << "4) Subtraction" << endl;
	cout << "Enter a number from 1 to 4 to select an operator" << endl;
	cin >> x;
	cout << "Enter two operand" << endl;
	cin >> a;
	cin >> b;

	switch (x)
	{
	case 1:
		cout << a << "*" << b << "=" << a * b << endl;
		break;
	case 2:
		cout << a << "/" << b << "=" << a / b << endl;
		break;
	case 3:
		cout << a << "+" << b << "=" << a + b << endl;
		break;
	case 4:
		cout << a << "-" << b << "=" << a - b << endl;
		break;
	default:
		cout << "ERROR";
		break;
	}
	return 0;
	system("pause");
}



