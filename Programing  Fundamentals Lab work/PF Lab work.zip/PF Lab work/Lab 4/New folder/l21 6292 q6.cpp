#include<iostream>
using namespace std;
int main()
{
    int x;
    cout<<"Enter Any number:";
    cin>>x;
    int y;
    cout<<"factors:";
    for(y=1;y<=x;y=y+1){
    if(x%y==0){
    cout<<""<<y<<" ";
    }
    }
    return 0;
    system("pause");
    
}