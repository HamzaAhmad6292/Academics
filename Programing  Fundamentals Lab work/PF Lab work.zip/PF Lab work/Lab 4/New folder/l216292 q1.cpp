#include<iostream>
using namespace std;
int main()
{
	int x;
	cout<<"Enter a Number:";
	cin>>x;
	int sum=0;
	int y;
	cout<<"The list of odd nuumbers:";
		for(y=1;y<x;y=y+1){
			if (y%2 != 0)
			{
			    cout<<y<<"-";
			    sum=sum+y;
			}
		}
		cout<<endl<<"Sum:"<<sum;
		return 0;
		system("pause");
}