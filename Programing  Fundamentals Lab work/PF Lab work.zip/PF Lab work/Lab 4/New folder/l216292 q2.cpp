#include<iostream>
using namespace std;
int main()
{
int x;
int y;
cout<<"Enter first number:";
cin>>x;
int c;
cout<<"Enter Second Number:";
cin>>y;
int mul=0;
for(c=1;c<=x;c=c+1)
{
    mul=mul+y;
}
cout<<mul;
return 0;
system("pause");
}