#include<iostream>
using namespace std;
int main()
{
    int x;
    cout<<"Enter any number=";
    cin>>x;
    int y=x%2;
    if ((x>=1)&(x<=9)){
    switch (y)
    {
    case 0:
    cout<<"Ther number is even";
    break;
    default:
    cout<<"The Number is odd";
    break;
    }
    }
    else
    cout<<"The Number is not Natural Number ";
    return 0;
    system("pause");
    
}
