#include<iostream>
using namespace std;
int main(){
int x;
cout <<"Enter any Number:";
cin>>x;
int sq;
int y;
int dif;
int A;
int plus=0;
int square;

int sum=0;
for(y=1;y<=x;y=y+1)
{
sq=y*y;

sum=sum+sq;
plus=plus+y;

}
square=plus*plus;
dif=square-sum;
cout<<square<<"-"<<sum<<"="<<dif;
return 0;
system("pause");




}