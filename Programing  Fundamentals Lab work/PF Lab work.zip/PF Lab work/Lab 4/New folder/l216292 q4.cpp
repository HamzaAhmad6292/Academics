#include<iostream>
using namespace std;
int main(){
int x;
cout <<"Enter any Number:";
cin>>x;
int sq;
int y;
int avg;
int sum=0;
for(y=1;y<=x;y=y+1)
{
sq=y*y;
cout<<sq<<" "<<endl;

sum=sum+sq;
}
avg=sum/x;
cout<<"sum="<<sum<<endl;
cout <<"Average="<<avg;
return 0;
system("pause");


}
