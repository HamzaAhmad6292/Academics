#include <iostream>
#include <conio.h>
using namespace std;
void check(char words2[][21], int r, int wcount, char a[]) 
{
	int found = 0;
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < wcount; j++) {
			if (a[j] == words2[i][j]) {
				found++;
			}
		}
		if (found == wcount) {
			cout << endl << words2[i] << " ";
		}
		found = 0;
	}
}


int main() {
	int wcount = 0;
	int i = 0;
	char words2[20][21];
	char words[20][21] = {
						"apply",
						"application",
						"bat",
						"batch",
						"battle",
						"compute",
						"computer",
						"compare",
						"device",
						"develop",
						"developer",
						"function",
						"functional",
						"fucntionality",
						"handle",
						"handler",
						"handling",
						"system",
						"systemic",
						"systole"
	};

	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 21; j++) {
			words2[i][j] = words[i][j];
		}
	}


	char a[21];
	while (true) {
		a[i] = _getch();
		system("cls");
		wcount++;
		for (int i = 0; i < wcount; i++) {
			cout << a[i] << " ";
		}
		if (a[i] == 13) {
			system("cls");
			cout << "Enter pressed" << endl;
		}
		else if (a[i] == '0') {
			break;
		}
		else {
			check(words2, 20, wcount,a);
		}
		i++;
	}
	cout << endl << "program terminated" << endl;
	return 0;
}