#include<iostream>
using namespace std;

void bigsum(int arr1[], int arr2[],int arr3[], int size)

{
	bool flag = false;
	int x = 0;
	int y;
	int temp;
	int ans;
	int a;
	for (int i = 0; i < size + 1; i++) {
		arr3[i] = 0;
	}

	int carry = 0;
	
	for (int i = size - 1; i >= 0; i--) {
		temp = arr1[i] + arr2[i] + carry;
		carry = 0;
		arr3[i + 1] = temp % 10;
		carry = temp / 10;
	}
	cout << "Big1+ Big2:";
	for (a = 0; a <= size; a++)
	{
		if (arr3[a] != 0 || flag==true) {
			cout << arr3[a];
			flag = true;
		}
	}

	cout << endl;
}
void bigdif(int arr1[], int arr2[], int arr_ans[], int sz) {
	bool flag = false;
	for (int i = 0; i < sz; i++) {
		arr_ans[i] = 0;
	}
	for (int i = sz - 1; i > 0; i--) {
		if (arr2[i] > arr1[i]) {
			arr1[i] += 10;
			arr1[i - 1] -= 1;
		}
		arr_ans[i] = arr1[i] - arr2[i];
	}
	cout << "Big1 - Big2 : ";
	for (int i = 0; i < sz; i++) {
		if (arr_ans[i] != 0 || flag == true) {
			cout << arr_ans[i];
			flag = true;
		}
	}
	cout << endl;
}
void bigin(int arr[], int size)
{
	int x;
	cout << "Enter bigint:";
	for (x = 0; x < size; x++)
	{
		cin >> arr[x];
	}
}
void bigout(int arr[], int sz) {
	bool flag = false;
	cout << "Big : ";
	for (int i = 0; i < sz; i++) {
		if (arr[i] != 0 || flag == true) {
			cout << arr[i];
			flag = true;
		}
	}
	cout << endl;
}
int main()
{
	const int size = 10;
	int big1[size];
	int big2[size];
	int big3[size];
	int big4[size];
	cout << "Enter" << size << " long digit number " << endl;

	bigin(big1, size);
	bigin(big2, size);
	bigout(big1, size);
	cout << endl;
	bigout(big2, size);
	cout << endl;
	bigsum(big1, big2, big3 ,size);
	cout << endl;
	bigdif(big1, big2, big4, size);
	cout << endl;

	system("pause");
	return 0;
}