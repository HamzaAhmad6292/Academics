#include <iostream>
using namespace std;
void displaywords(char words[15][11])

{
	int x;
	int y;
	for (x = 0; x < 15; x++)
	{
		cout << words[x] << endl;
	}
	cout << endl << endl;

}
void displaygrid(char grid[10][10])
{
	int x;
	int y;
	for (x = 0; x < 10; x++)
	{
		cout << x << "|";
		for (y = 0; y < 10; y++)
		{
			cout << grid[x][y] << "  ";
		}
		cout << endl;
	}
}




void direction7(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y = u;
	int z = r;
	int count = 1;
	bool flag = false;
	while ((y >= 0) && (z >= 0) && (x < 11))
	{
		if (words[a][x] == grid[y][z])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;
		--y;
		--z;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 7" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction3(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y = u;
	int z = r;
	int count = 1;
	bool flag = false;
	while ((y  <10) && (z < 10) && (x < 11))
	{
		if (words[a][x] == grid[y][z])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;
		++y;
		++z;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 3" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction5(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y = u;
	int z = r;
	int count = 1;
	bool flag = false;
	while ((y < 11) && (z >= 0) && (x < 11))
	{
		if (words[a][x] == grid[y][z])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;
		++y;
		--z;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 5" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction1(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y=u;
	int z = r;
	int count = 1;
	bool flag = false;
	while((y>=0)&&(z<10)&&(x<11))
	{
		if (words[a][x] == grid[y][z])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;
		--y;
		++z;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 1" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction6(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y;
	int count = 1;
	bool flag = false;
	for ((y = r); (y >= 0) && (x < 11); y--)

	{
		if (words[a][x] == grid[u][y])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 6" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}


void direction2(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y;
	int count = 1;
	bool flag = false;
	for ((y = r); (y <10 ) && (x < 11); y++)

	{
		if (words[a][x] == grid[u][y])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << " Direction 2" << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction0(int a, int u, int r, char words[15][11], char grid[10][10])
{
	int x = 0;
	int y;
	int count = 1;
	bool flag = false;
	for ((y = u); (y >= 0) && (x < 11); y--)

	{
		if (words[a][x] == grid[y][r])
		{
		     count++;
		}
		else
		{
			break;
		}
		x++;
		
	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 0" <<"      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void direction4(int a, int u, int r, char words[15][11], char grid[10][10])


{
	int x = 0;
	int y;
	int count = 1;
	bool flag = false;
	for ((y = u); (y <10 ) && (x < 11); y++)

	{
		if (words[a][x] == grid[y][r])
		{
			count++;
		}
		else
		{
			break;
		}
		x++;

	}
	if (count > 4)
	{
		cout << words[a] << "     " << "Direction 4 "  << "      " << " at: (" << u << " , " << r << ")";
		cout << endl;
	}

}
void man(char grid[10][10], char words[15][11])

{

	int i;
	int j;
	int a;
	for (a = 0; a < 15; a++)
	{
		for (i = 0; i < 10; i++)
		{
			for (j = 0; j < 10; j++)
			{
				if (words[a][0] == grid[i][j])
				{
					
					direction0(a, i, j, words, grid);
					direction4(a, i, j, words, grid);
					direction6(a, i, j, words, grid);
					direction2(a, i, j, words, grid);
					direction1(a, i, j, words, grid);
					direction5(a, i, j, words, grid);
					direction3(a, i, j, words, grid);
					direction7(a, i, j, words, grid);
				}
				else
					continue;
			}
		}
	}
}

int main()


{


	char grid[10][10] = {
						{ 'T', 'N', 'E', 'M', 'N', 'G', 'I', 'S', 'S', 'A'},
						{ 'B', 'N', 'C', 'A', 'O', 'M', 'P', 'J', 'W', 'f'},
						{ 'C', 'L', 'A', 'R', 'I', 'F', 'Y', 'H', 'X', 'R'},
						{ 'L', 'O', 'S', 'C', 'T', 'G', 'H', 'C', 'E', 'V'},
						{ 'A', 'N', 'M', 'H', 'S', 'Y', 'S', 'T', 'E', 'M'},
						{ 'S', 'T', 'I', 'P', 'E', 'Q', 'N', 'A', 'F', 'E'},
						{ 'S', 'S', 'E', 'Q', 'U', 'E', 'N', 'C', 'E', 'M'},
						{ 'U', 'E', 'F', 'N', 'Q', 'T', 'G', 'Q', 'W', 'O'},
						{ 'D', 'K', 'R', 'O', 'W', 'T', 'E', 'N', 'K', 'R'},
						{ 'A', 'O', 'M', 'O', 'D', 'N', 'A', 'R', 'T', 'Y'},
	};
	char words[15][11] = {
							"COMPUTER",
							"QUESTION",
							"CLARIFY",
							"NETWORK",
							"SYSTEM",
							"CLASS",
							"SEQUENCE",
							"CATCH",
							"MEMORY",
							"RANDOM",
							"ASSIGNMENT",
							"MARCH",
							"SCANT",
							"SPEED",
							"ENTER"

	};
	int x;
	int y;
	





	displaywords(words);
	cout << endl << endl;
	cout << "  ";
	for (x = 0; x < 10; x++)
	{
		cout << x << "  ";
	}
	cout << endl;
	for (x = 0; x < 10; x++)
	{
		cout << "---";
	}
	cout << endl;
	displaygrid(grid);
	cout << endl << endl;
	man(grid, words);
	system("pause");
	return 0;

}