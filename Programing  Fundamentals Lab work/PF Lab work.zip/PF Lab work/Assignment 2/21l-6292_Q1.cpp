// 21L-6292 Q1 part a

#include<iostream>
using namespace std;
int main()
{

	int i = 0;
	int j;
	int k;
	int ans = 0;
	int x;
	int y;
	int z;

	int sum = 0;
	int add = 0;
	int arr[10] = { 2,4,6,8,10,12,14,16,18,20 };
	for (i = 0; i <= 8; i++)
	{
		    j = i + 1;
	        k = i + 2;
		sum = arr[i] + arr[j] + arr[k];
		if (sum > add)
		{
			ans = sum;
			x = i;
			y = j;
			z = k;

		}
			add = sum;

	}
	cout << "Max triplet:" << ans << endl;
	cout << "Triplet valuse:" << arr[x] << " " << arr[y] << " " << arr[z] << endl;
	system("pause");
	return 0;



	
	
}

// 21L-6292 Q1 part b
 