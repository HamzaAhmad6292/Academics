#include <iostream>
using namespace std;

int main()
{
    char a[20] = {'B','D','A','A','C','A','B','A','C','D','B','C','D','A','D','C','C','B','D','A'};
    int marks=0;
   char ans[20];
    cout << "Enter answers:" << endl;
          for(int i=0 ; i<20 ; i++)
          {
        cin >> ans[i] ;
          }
   
    for(int x=0 ; x<20 ; x++)
    {
        if (ans[x]==a[x])
        {
            marks++ ;
        }
    }
   
   
    if(marks>=18){
        cout << "A grade";
    }
    else if((marks<18) && (marks>=14)){
        cout << " B grade";
    }
    else if((marks<14) && (marks>=10)){
        cout << " C grade";
    }
    else if(marks<10){
        cout << " F grade";
    }
   system("pause");
    return 0;
}
