#include<iostream>
#include <cstdlib>
using namespace std;
int main()
{
	int org[2][5];
	int arr[2][5];
	cout<<"Enter your premium bond number:";
	cout<<endl;
	int count=0;
	bool flag=true;

	for(int i=0;i<2;i++)
	{
		for(int j=0;j<5;j++)
		{
			cin>>arr[i][j];
		}
	}
	cout<<endl;
	cout<<"Premium Bond Prize Winner";
	cout<<endl<<endl;
	for(int a=0;a<2;a++)
	{
		for(int b=0;b<5;b++)
		{
			int r = (rand() % 9) + 1;
			org[a][b]=r;
		}
	}
	for(int x=0;x<2;x++)
	{
		for(int y=0;y<5;y++)
		{
			if(org[x][y]!=arr[x][y])
			{
				count =count +1;
				flag=false;
			}
		}
		

	}
	for(int a=0;a<2;a++)
	{
		for(int b=0;b<5;b++)
		{
			cout<<org[a][b]<<" ";
		}
		cout<<endl;
	}
	if(flag==false)
		{
			cout<<"You lost the prize from "<<count<<" numbers";
		}
		else
		  {
			  cout<<"Congrats you are the winner ";
		cout<<endl;
		}
		system("pause");
		return 0;


}