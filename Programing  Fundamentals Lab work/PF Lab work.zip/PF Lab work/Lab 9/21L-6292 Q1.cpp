#include<iostream>
using namespace std;
int main()
{
	int arr[20][20];
	int brr[20][20];
	int x;
	int y;
	int i;
	int j;
	int dif[20][20];

	cout<<"Enter number of rows:";
	cin>>x;
	cout<<endl;
	cout<<"Enter number of columns:";
	cin>>y;
	cout<<"Enter first matrix"<<endl;
	for(i=0;i<x;i++)
	{
		for( j=0;j<y;j++)
		{
			cin>>arr[i][j];
		}


	}
	cout<<"Enter elements second Matrix:"<<endl;
	for( int a=0;a<x;a++)
	{
		for( int b=0;b<y;b++)
		{
			cin>>brr[a][b];
		}
		

	}
	cout<<endl;
	for(int r=0;r<x;r++)
	{
		for(int c=0;c<y;c++)
		{
			dif[r][c]=arr[r][c]-brr[r][c];
		}
	}
	cout<<endl;
	cout<<"A-B";
	cout<<endl;
	for(int n=0;n<x;n++)
	{
		for( int m=0;m<y;m++)
		{
			cout<<dif[n][m]<<" ";
		}

		cout<<endl;

	}
	
	system("pause");
	return 0;

}