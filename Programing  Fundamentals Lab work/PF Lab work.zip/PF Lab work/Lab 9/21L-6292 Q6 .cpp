#include<iostream>
#include<string.h>
using namespace std;
int main()
{
        char a[50][50],f[50];
        cout<<"Enter Names of students"<<endl;
        for(int x=0;x<50;x++)
        {
                cin>>a[x];
        }
        for(int y=1;y<50;y++)
        {
                for(int i=1;i<50;i++)

                {
                        if(strcmp(a[i-1],a[i])>0)
                        {
                                strcpy(f, a[i-1]);
                                strcpy(a[i-1],a[i]);
                                strcpy(a[i],f);
                        }
                }
        }
        cout<<"Names in Alphabetical Order :"<<endl;
        for(int z=0;z<50;z++)
        {
                cout<<a[z];
cout<<endl;
        }
	system("pause");
        return 0;
}
