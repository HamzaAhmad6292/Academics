#include<iostream>
using namespace std;
void find (int brr[],int n)
{
    bool flag=true;
	for(int a=0;a<8;a++)
	{
		if(n==brr[a])
		{
			cout<<"The Number "<<n <<" exist at index "<<a<<endl;
			flag=true;
			break;
			
		}
		else 
		flag=false;

	}
	if (flag==false);
	cout<<"----ERROR----";
}

int main()
{
	int arr[8]={9,55,60,81,49,66,49,10};
	int n;
		cout<<"Enter search element:";
		cin>>n;
	int x;
	int y;
	find(arr,n);

	system("pause");
		return 0;



}