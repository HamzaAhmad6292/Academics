#include<iostream>
using namespace std;
int main()
{
    char arr[50];
    cin>>arr;
    int x;
    int y;
    for(x=0;x<50;x++)
    {
        if((arr[x]<65)||(arr[x]>122))
        {
           break; 
        }
        if((arr[x]>='a')&&(arr[x]<='z'))
        {
            arr[x]=arr[x]-32;
        }
        else
        arr[x]=32+arr[x];
    }
    
    cout<<arr;
    
    system("pause");
    return 0;
    
}
