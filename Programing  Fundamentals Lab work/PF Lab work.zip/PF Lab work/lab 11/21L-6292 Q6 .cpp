#include<iostream>
#include<string>
using namespace std;




union cars1 {
	char name[20];
	int price;
	char clr[10];
}var1;





struct cars2 {
	char name[20];
	int price;
	char clr[10];
}var2;





int main() {

	cout << "Please enter Model Name : ";
	cin.get(var1.name, 20);
	cin >> var1.name;
	cout << "Enter Price : ";
	cin >> var1.price;
	cout << "Enter Colour : ";
	cin.get(var1.clr, 10);
	cout << sizeof(cars1);
	cout << "Therefore it can be said that unions save space and are more effecient but structs are more useful because of their reusaeability ";

	return 0;
}