#include<iostream>
using namespace std;
struct sap {
	int id;
	char name[20];
	int pay;
	int sales;
	int time;
};

int reward(int pay) {
	if (pay > 10000) {
		return 0.02 * pay;
	}
	else return 0;
}
int net_sal(int pay, int overtime, int reward) {
	return pay + overtime + reward;
}
int CalculateOvertime(int overtime) {
	return 8 * overtime;
}
void BestSalesPerson(sap a[10]) {
	cout << "......Print Reward Winners......" << endl;
	cout << "Sales Person    Reward";
	for (int i = 0; i < 10; i++) {
		if (a[i].pay > 10000) {
			cout << a[i].name << "   " << reward;
		}
	}
}
int main() {



	int num, ex;
	int rwrd = 0;
	sap arr[10];
	int i = 1;

	for (; i < 11; i++) {
		cout << "....Input Record " << i << "...." << en;
		cout << "Enter Salesperson ID:";
		cin >> arr[i].id;
		cout << "Enter Salesperson Name: ";
		cin >> arr[i].name;
		cout << "Enter Salary: ";
		cin >> arr[i].pay;
		cout << "Enter Sales: ";
		cin >> arr[i].sales;
		cout << "Overtime Hours Worked: ";
		cin >> arr[i].time;
	}
	cout << ".......Salesperson " << i << " infromation...."; cout << endl;
	for (i = 1; i < 11; i++) {
		cout << "Salesperson ID:";
		cout << arr[i].id;
		cout << endl;
		cout << "Salesperson Name: ";
		cout << arr[i].name;
		cout << endl << "Salary: ";
		cout << arr[i].pay;
		cout << endl;
		cout << "Sales: ";
		cout << arr[i].sales;
		cout << endl << "Overtime Hours Worked: ";
		cout << arr[i].time;
		cout << endl;
		cout << "-------------" << endl;
	}



	while (num != 0) {
		cout << "1. Calculate net salary of the salesperson." << endl;
		cout << "2. Calculate Weekly reward of a salesperson." << endl;
		cout << "3. Calculate Overtime of the salesperson." << endl;
		cout << "4. Print the list of Reward winners of the week." << endl;
		cout << " 5. Press 0 to terminate this program." << endl;
		cout << "Enter a number for 1 to 5 : ";
		cin >> num;

		cout << "Enter Salesperson ID: ";
		cin >> ex;
		ex = ex - 1;


		if (num == 1) {
			cout << "Reward : " << reward(arr[i].pay);
		}
		if (num == 2) {
			net_sal(arr[i].pay, arr[i].time, rwrd);
		}
		if (num == 3) {
			CalculateOvertime(arr[i].time);
		}
		if (num == 4) {
			BestSalesPerson(arr);
		}
		if (num == 0) {
			break;
		}
	}
	return 0;
}