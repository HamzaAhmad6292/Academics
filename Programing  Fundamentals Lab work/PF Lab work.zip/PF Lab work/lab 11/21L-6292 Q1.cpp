#include<iostream>
using namespace std;
struct foot_inch{
	int foot;
	int inch;
}v1,v2,v3;

int main()
{
  cout<<"Enter height:";
	  cin>>v1.foot;
	  
	  cin>>v1.inch;
	  cout<<"Enter height:";
	  cin>>v2.foot;
	  cin>>v2.inch;

	  v3.inch=v1.inch+v2.inch;
	  v3.foot=v1.foot+v2.foot;
	  cout<<v3.foot<<" "<<v3.inch<<endl;

	  system("pause");
	  return 0;


}     