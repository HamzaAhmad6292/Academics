#include<iostream>
using namespace std;
struct neo {
	int salespersonID;
	 char name[20] ;
	 int pay;
	 int sales;
	 int time;



};

int main()
{
	neo arr[11];
   int i;
    for(i=1;i<11;i++)
	{
		cout<<"----Input Record----"<<i;
		cout<<endl;
		cout<<"Enter sales person ID:";
			cin>>arr[i].salespersonID;
			cout<<endl;
			cout<<"Enter salesperson name:";
			cin>>arr[i].name;
			cout<<endl;
			cout<<"Enter salary:";
			cin>>arr[i].pay;
			cout<<endl;
			cout<<endl;
			cout<<"Enter Sales:";
			cin>>arr[i].sales;
			cout<<endl;
			cout<<"Enter overtime hours";
			cin>>arr[i].time;
			cout<<endl;
	}
	int j;
	for(j=1;j<11;j++)
	{
		cout<<"----Salesperson "<<i<<"information----";
		cout<<" Salesperson ID:";
			cout<<arr[j].salespersonID;
			cout<<" Salesperson name:";
			cout<<arr[j].name<<endl;;
			cout<<" Salary:";
			cout<<arr[j].pay<<endl;
			cout<<" Sales:"<<endl;
			cout<<arr[j].sales<<endl;;
			cout<<"Overtime hours";
			cout<<arr[j].time<<endl;
	}
	system("pause");
	return 0;


	
	
}