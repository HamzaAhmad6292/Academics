#include<iostream>
using namespace std;
union Square
{
	int Height;
	int Width;
	int Square;
};
struct Sqr
{
	int Height;
	int Width;
	int Square;
};
int main()
{
	union Square p1;
	struct Sqr u1;
	cout << "Enter Height: ";
	cin >> p1.Height;
	cout << "Enter Width: ";
	cin >> p1.Width;
	p1.Square = p1.Height * p1.Width;
	cout << "Square = " << p1.Square << endl;
	cout << "Struc-Enter Height: ";
	cin >> u1.Height;
	cout << "Struc-Enter Width: ";
	cin >> u1.Width;
	u1.Square = u1.Height * u1.Width;
	cout << "Struc-Square = " << u1.Square << endl;
	cout << "Size of Union: " << sizeof(p1) << endl;
	cout << "Size of Structure: " << sizeof(u1) << endl;
	system("Pause");
	return 0;
}

//union is more effieint than struct because of its less size.
//Both union and structure give desired output.