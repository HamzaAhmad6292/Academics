#include <iostream>
#include <cstring>
using namespace std;
union person
{
	char gender[30];
	int age;
	char name[30];
};
struct x {
	char name[10];
	char gndr;
	int age;
}s1;


int main()
{
	union person p1;
	p1.age = 18;
	cout << "Age: " << p1.age << endl;
	strcpy(p1.name, "Hassan");
	cout << "Name: " << p1.name << endl;
	strcpy(p1.gender, "Male");
	cout << "Gender: " << p1.gender << endl;
	

	cout << "Enter name: ";
	cin >> s1.name;
	cout << "Enter age: ";
	cin >> s1.age;
	cout << "Enter Gender: ";
	cin >> s1.gndr;
	cout << "Size of this structure is : " << sizeof(x);

	cout << endl;





	return 0;


	//Gender cannot be displayed from structure
		//union gives us the desired output.

	// therefore it can be said that union uses less space and hence useful in some situations 
}