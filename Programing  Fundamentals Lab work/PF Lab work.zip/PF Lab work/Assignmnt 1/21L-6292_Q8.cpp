#include<iostream>
using namespace std;
int pow(int x, int y)
{

	int n;
	int result = 1;

	for (n = 0; n < y; n++)
	{
		result = result * x;


	}
	return result;

}
int poco(int num)
{

	int x;
	int i = 0;
	int n = num;
	int nu = num;
	int result = 0;
	while (num > 0)
	{
		x = num % 10;
		num = num / 10;
		i = i + 1;
	}
	while (n > 0)
	{
		x = n % 10;
		n = n / 10;
		result = result + pow(x, i);

	}


		return result;
}

int main()
{
	int num;
	cout << "Enter any Number:";
	cin >> num;
	cout << "The special Number from 0 to " << num << " are:" << endl << endl;
	for (int x = 0; x <= num; x++)
	{
		int result = poco(x);
		if (result == x)
		{
			cout << result << " ";
		}
	}
	
	return 0;
	system("pause");
}