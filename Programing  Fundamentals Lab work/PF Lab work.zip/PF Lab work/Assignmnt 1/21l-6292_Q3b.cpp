#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter n:";
	cin >> num;
	int rev = 0;
	int x;
	int extra = num;
	while (num > 0)
	{
		x = num % 10;
		rev = (rev * 10) + x;
		num = num / 10;

	} 
	cout << rev;
	if (extra == rev)
	{
		cout << " plindrome ";
	}
	else
	{
		cout << "not a plindrome ";
	}
	return 0;
	system("pause");
}