#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter height of the triangle:";
	cin >> num;
	int i;
	int j;
	int space;
	int k;
	for (i = 1, k = 0; i < num; ++i, k = 0)
	{
		for (space = 1; space <= num - i; ++space)
		{
			cout << "  ";
		}

		while (k != 2 * i - 1)
		{
			cout << "* ";
			++k;
		}
		cout << endl;
	}
	for (i = num; i >= 1; --i)
	{
		for (space = 0; space < num - i; ++space)
			cout << "  ";

		for (j = i; j <= 2 * i - 1; ++j)
			cout << "* ";

		for (j = 0; j < i - 1; ++j)
			cout << "* ";

		cout << endl;
	}

	return 0;
}