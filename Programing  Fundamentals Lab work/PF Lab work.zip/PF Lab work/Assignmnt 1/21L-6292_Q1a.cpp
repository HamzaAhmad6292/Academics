#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter Any Number:";
	cin >> num;
	int x;
	int y = 0;
	while (num > 0)
	{
		x = num % 10;
		num = num / 10;
		y = y + 1;
	}
	float sum1 = 1.0;
	float sum2 = 0.33;
	float pi = 0.0;
	int a;
	int d1 = 1;
	int d2 = 3;
	float diff1;
	float sum;
	for (a = 0; a <= y; a++)
	{
		sum = sum1 - sum2;
		sum1 = 1 / d1;
		sum2 = 1 / d2;
		d1 = d1 + 4;
		d2 = d2 + 4;
		pi = sum + pi;
	}

	cout << pi * 4;
	return 0;
	system("pause");
}