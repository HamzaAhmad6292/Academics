#include<iostream>

using namespace std;
int pow(int x, int y)
{
	int z;
	int c = x;
	for (z = 1; z < y; z++)
	{
		x = x * c;


	}
	return x;
}
int main()
{
	int num;
	int x;
	cout << "Enter Any binary=";
	cin >> num;
	int y;
	int a;
	int sum = 0;
	for (a = 0; num > 0; a++)
	{
		x = num % 10;
		num = num / 10;
		y = x * (pow(2, a));
		sum = sum + y;

	}
	cout << sum;
	return 0;
	system("pause");
}