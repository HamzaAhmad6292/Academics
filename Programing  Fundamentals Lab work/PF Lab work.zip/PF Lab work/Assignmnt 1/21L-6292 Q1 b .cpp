#include <iostream>
using namespace std;
int main()
{
    int x;
    int power;
    cout << "Enter the number of times to evalure:";
    cin >> x;
    int i;
    cout << "enter x:";
    cin >> power;
    float sum = 1;
    float extra = 1;
 

    for ( i = 1; i <= x; i++) 
    
    {
        extra = (extra * power) / i;
        sum = sum + extra;
    }

    cout << sum;

    return 0;
    system("pause");

}
