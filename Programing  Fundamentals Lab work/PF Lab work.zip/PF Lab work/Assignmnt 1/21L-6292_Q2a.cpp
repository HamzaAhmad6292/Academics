#include<iostream>
using namespace std;
long main()
{

        int remainder;
        long n;
        long binary = 0, i = 1;
        cout << "Enter Denary number:";
        cin>>n

        while (n != 0) {
            remainder = n % 2;
            n = n / 2;
            
        }
        cout << remainder << i;
        return 0;
        system("pause");

}