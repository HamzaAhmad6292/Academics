#include <iostream>
using namespace std;

int main()
{
    int x;
    int y;
    int z;
    int a;
    int b;
    bool flag = true;

    while (true)
    {
        cin >> x;
        if (x == 1) 
        {
            cin >> y;
            if (y == 0)
            {
                cin >> z;
                if (z == 1)
                {
                    cin >> a;
                    if (a == 0)
                        cin >> b;
                    if (b == 1)
                    {
                        cout << "Input terminated";
                        break;
                    }
                }
            }
        }

    }

    return 0;
    system("pause");
}