#include<iostream>
using namespace std;
int main()
{
	int  num;
	cout << "Enter a number for prime factorization:";
	cin >> num;
	int x;
	int y;
	int z;
	int a;
	int n;
	bool prime = true;


	if ((num == 0) || (num == 1))
	{
		prime = false;
	}
	else
	{
		for (n = 2; n < num / 2; ++n)
		{
			y = num % n;
			if (y == 0)
			{
				prime = false;
				break;
			}
		}
	}
	if (prime == true)
	{
		cout << num << " is prime ";
	}
	else
	{


		for (x = 2; x < num; x++)
		{
			y = num % x;
			bool prime = true;
			if (y == 0)
			{
				if ((x == 0) || (x == 1))
				{
					prime = false;
				}
				else
				{
					for (z = 2; z <= x / 2; ++z)
					{
						a = x % z;
						if (a == 0)
						{
							prime = false;
							break;
						}
					}
				}
				if (prime == true)
				{
					cout << x << " ";
				}

			}
		}
	}
	return 0;
	system("pause");

}