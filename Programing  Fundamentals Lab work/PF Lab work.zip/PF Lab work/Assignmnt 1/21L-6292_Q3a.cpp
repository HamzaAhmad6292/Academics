#include<iostream>
using namespace std;
int main()
{
	int num;
	int x;
	cout << "Enter n:";
	cin >> num;
	cout << "reverse:";
	while (num > 0)
	{
		x = num % 10;
		num = num / 10;
		cout << x;
	}
	return 0;
	system("pause");
}