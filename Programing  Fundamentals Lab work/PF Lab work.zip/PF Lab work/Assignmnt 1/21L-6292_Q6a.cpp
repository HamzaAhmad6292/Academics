#include<iostream>
using namespace std;
int main()
{
	int num;
	cout << "Enter height of the triangle:";
	cin >> num;
	int x;	
	int y;
	int z;
	int space;
	
	for (x = 1; x <=num; ++x)
	{
		int extra = 0;  
		for (z = 0; z <=num-x; ++z)
		{
			cout << " ";
			
		}
		
	     	
			
		while (extra != 2*x-1)
		{
			cout << "*";
			++extra;
		}
			cout << endl;
	}
	return 0;
}