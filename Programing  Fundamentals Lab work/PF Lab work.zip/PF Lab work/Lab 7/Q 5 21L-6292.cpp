#include<iostream>
using namespace std;




int factorial(int x)                  // number 1
{
	int y;
	int result = 1;
	for (y = 1; y <= x; y = y + 1)
	{
		result = result * y;

	}
	return result;
}

void swap(int& x, int& y)             // number 2
{

	x = x + y;
	y = x - y;
	x = x - y;

}

int pali(int x)                      // number 3
{
	int y;
	int z = 0;
	int a;
	int b;
	for (; x > 0;)
	{
		y = x % 10;
		x = x / 10;
		z = (z * 10) + y;
	}
	return z;
}

void series(int n)					// number 4
{
	static int x = 0;
	static int y = 1;
	int z;
	for (z = 3; z < n; z++)
	{
		if (n % 2 == 0)
		{
			cout << " " << x;
			cout << " " << y;
		}

		else
		{
			cout << " " << x;
			if (z < n - 1)
			{
				cout << " " << y;
			}
		}
		x = x + y;

		y = y + x;
	}
}






int main()
{
	int inc;
	cout << "Enter a numbe from 1 t0 4:" << endl;
	cin >> inc;

	if (inc == 1)
	{
		cout << "-------Executing task 1-------" << endl << endl;
		int num;
		int result;
		cout << "Enter a number:";
		cin >> num;
		result = factorial(num);
		cout << "Factorial of " << num << " is:" << result;

	}

	else if (inc == 2)
	{
		cout << "-------Executing task 2-------" << endl << endl;

		int x, y;
		cout << "Enter 1st variable value:";
		cin >> x;
		cout << "Enter 2nd variable value:";
		cin >> y;
		swap(x, y);
		cout << "The swaped value of 1st varibale :" << x << endl;
		cout << "The swaped value of 2nd varibale :" << y;


	}

	else if (inc == 3)
	{
		cout << "-------Executing task 3-------" << endl << endl;

		int num;
		int result;
		cout << "Enter a string:";
		cin >> num;
		result = pali(num);

		if (result == num)
			cout << "Yes";
		else {
			cout << "no";
		}

	}

	else if (inc == 4)
	{
		cout << "-------Executing task 4-------" << endl << endl;

		int num;
		cout << "Enter the times you want the series:";
		cin >> num;
		series(num);

	}

	else
	{
		cout << "Error";
	}
	return 0;
	system("pause");

}