#include<iostream>
using namespace std;
int pali(int x)
{
	int y;
	int z=0;
	int a;
	int b;
	for(;x>0;)
	{
	    a=y;
		y=x%10;
			x=x/10;
		z=(z*10)+y;
	}
	 return z;
}
int main()
{
    int num;
    int result;
    cout<<"Enter a string:";
    cin >>num;
    result=pali(num);
    
    if (result==num)
    cout<<"Yes";
    else{
    cout<<"no";
    }
    return 0;
    system("pause");
}

