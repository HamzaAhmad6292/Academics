
int factorial(int x)
{
	int y;
	int result=1;
	for(y=1;y<=x;y=y+1)
	{
		result=result*y;
	
	}
	return result;
}
int mai1()
{
	int num;
	int result;
	cout<<"Enter a number:";
	cin>>num;
	result=factorial(num);
	cout<<"Factorial of "<<num<<" is:"<<result;
	return 0;
	system("pause");
}

