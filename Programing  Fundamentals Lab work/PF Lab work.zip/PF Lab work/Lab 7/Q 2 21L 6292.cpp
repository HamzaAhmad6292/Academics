#include<iostream>
using namespace std;
void swap(int &x,int &y)
{

	x=x+y;
	y=x-y;
	x=x-y;
	
}
int main()
{
	int x,y;
	cout<<"Enter 1st variable value:";
	cin>>x;
	cout<<"Enter 2nd variable value:";
	cin>>y;
	swap(x,y);
	cout<<"The swaped value of 1st varibale :"<< x<<endl;
	cout<<"The swaped value of 2nd varibale :"<< y;
	return 0;
	system("pause");

}