#include<iostream>
using namespace std;
void series(int n)
{
	static int x = 0;
	static int y = 1;
	int z;
	for (z = 3; z < n; z++)
	{  
		if (n % 2 == 0)
		{
			cout << " " << x;
			cout << " " << y;
		}

		else
		{
		cout << " " << x;
		if (z < n - 1)
		{
			cout << " " << y;
		}
		}
		x = x + y;

		y = y + x;
	}
}
int main()
{
	int num;
	cout << "Enter the times you want the series:";
	cin >> num;
	 series(num);
	 return 0;
	 system("pause");
}